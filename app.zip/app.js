var express = require('express');
var path = require('path');
var app = express();
const { engine } = require('express-handlebars');
const port = process.env.port || 3000; //it will check the post number mentioned in the env file, otherwise it will consider 3000.

//We are using this middleware for setting up the static path as /public for accessing static content such as js, css, anf images.
app.use(express.static(path.join(__dirname, 'public')));

// Here we are settingt up hbs template engine
app.engine('.hbs', engine({ extname: '.hbs' }));
app.set('view engine', 'hbs');

//This is root url or we can say that this is the entry point of the system. User will be navigated to the index.hbs file.
app.get('/', function (req, res) {
    res.render('index', { title: 'Express' });
});

//when user will write the path /user behind the url, he will get message 'respond with a resource'
app.get('/users', function (req, res) {
    res.send('respond with a resource');
});

//when system doesn't find the url user want to access, he will be redirected to the error page
app.get('*', function (req, res) {
    res.render('error', { title: 'Error', message: 'Wrong Route' });
});
app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`)
})